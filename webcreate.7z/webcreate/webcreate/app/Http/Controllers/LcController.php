<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class LcController extends Controller
{
    public function dashboard() {
        return view('dashboard', ['product_list' => Product::where('user_id', Auth()->user()->id)->get()]);
    }

    public function add(Request $request) {
        $product = new Product();

        $file = $request->file('image');
        $destinationPath = 'uploads';
        $file->move($destinationPath,$file->getClientOriginalName());

        $product->image = $file->getClientOriginalName();
        $product->title = $request->input('title');
        $product->price = $request->input("price");
        $product->user_id = Auth()->user()->id;

        $product->save();

        return redirect('/dashboard');
    }

    public function remove($id, Request $request) {
        Product::find($id)->delete();
        return redirect('/dashboard');
    }
}
