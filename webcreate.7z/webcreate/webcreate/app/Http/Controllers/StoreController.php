<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class StoreController extends Controller
{
    public function store($id, Request $request) {
        if($request->input('add')) {
            $request->session()->push('cart', $request->input('add'));
            return redirect("/store/$id");
        }

        return view('/store', ['product_list' => Product::where('user_id', $id)->get(), 'cart' => $request->session()->get('cart')]);
    }

    public function cart(Request $request) {
        $product_list = Product::whereIn('id', $request->session()->get('cart'))->get();
       
        $sum=0;
        foreach ($product_list as $product) $sum+=$product->price;

        return view('/cart', ['product_list' => $product_list, "sum" => $sum]);
    }
}
